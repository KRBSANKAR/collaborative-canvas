// Drawing state management is implemented inline in server.js for clarity.
