// Room management is kept simple in server.js for this demo.
