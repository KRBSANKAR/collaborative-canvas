import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { randomUUID } from 'crypto';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 3000;
app.use(express.static('client'));

const colorPool = [
  '#EF4444','#F59E0B','#10B981','#3B82F6','#8B5CF6','#EC4899',
  '#22D3EE','#A3E635','#F97316','#14B8A6','#6366F1','#84CC16'
];

function pickColor(idx) { return colorPool[idx % colorPool.length]; }

// In-memory room state
const rooms = new Map();
// room => { users: Map<socketId,{id,color}>, history: Op[], tombstones: Set<string>, undoStack: string[], version: number }

function ensureRoom(name) {
  if (!rooms.has(name)) {
    rooms.set(name, {
      users: new Map(),
      history: [],
      tombstones: new Set(),
      undoStack: [],
      version: 0
    });
  }
  return rooms.get(name);
}

io.on('connection', (socket) => {
  const roomName = (new URL(socket.handshake.headers.referer || 'http://localhost/?room=default')).searchParams.get('room') || 'default';
  const room = ensureRoom(roomName);

  const userId = randomUUID();
  const color = pickColor(room.users.size);
  room.users.set(socket.id, { id: userId, color });

  socket.join(roomName);

  // Send initial state
  socket.emit('init', {
    self: { id: userId, color },
    users: Array.from(room.users.values()),
    history: room.history,
    tombstones: Array.from(room.tombstones),
    version: room.version
  });

  // Notify others
  socket.to(roomName).emit('user:join', { id: userId, color });

  socket.on('cursor:update', (payload) => {
    socket.to(roomName).emit('cursor:update', { id: userId, x: payload.x, y: payload.y });
  });

  // Stroke streaming
  socket.on('stroke:begin', (op) => {
    // Authoritative mapping
    const opId = op.opId || randomUUID();
    const finalOp = {
      opId,
      author: userId,
      color: op.color,
      size: Math.max(1, Math.min(op.size || 4, 64)),
      mode: op.mode === 'erase' ? 'erase' : 'draw',
      points: [{ x: op.start.x, y: op.start.y, ts: op.ts || Date.now() }]
    };
    room.history.push(finalOp);
    room.version++;
    io.to(roomName).emit('stroke:begin', finalOp);
  });

  socket.on('stroke:points', (payload) => {
    const { opId, points } = payload || {};
    const op = room.history.find(o => o.opId === opId);
    if (!op) return;
    // sanity filter
    const clean = Array.isArray(points) ? points.filter(p => typeof p.x === 'number' && typeof p.y === 'number') : [];
    if (clean.length === 0) return;
    op.points.push(...clean);
    io.to(roomName).emit('stroke:points', { opId, points: clean });
  });

  socket.on('stroke:end', ({ opId }) => {
    io.to(roomName).emit('stroke:end', { opId });
  });

  // Global undo/redo
  socket.on('undo', () => {
    // find latest non-tombstoned op
    for (let i = room.history.length - 1; i >= 0; i--) {
      const op = room.history[i];
      if (!room.tombstones.has(op.opId)) {
        room.tombstones.add(op.opId);
        room.undoStack.push(op.opId);
        room.version++;
        io.to(roomName).emit('history:patch', { action: 'undo', opId: op.opId, version: room.version });
        break;
      }
    }
  });

  socket.on('redo', () => {
    const opId = room.undoStack.pop();
    if (opId && room.tombstones.has(opId)) {
      room.tombstones.delete(opId);
      room.version++;
      io.to(roomName).emit('history:patch', { action: 'redo', opId, version: room.version });
    }
  });

  socket.on('disconnect', () => {
    room.users.delete(socket.id);
    socket.to(roomName).emit('user:leave', { id: userId });
    if (room.users.size === 0 && room.history.length === 0) {
      rooms.delete(roomName);
    }
  });
});

httpServer.listen(PORT, () => {
  console.log('Server listening on http://localhost:' + PORT);
});
