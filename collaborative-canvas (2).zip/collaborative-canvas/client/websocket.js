export function connect() {
  const socket = io();
  return socket;
}
