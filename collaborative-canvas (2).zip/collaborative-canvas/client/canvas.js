import { connect } from './websocket.js';

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: false });
const cursorsLayer = document.getElementById('cursors');
const usersList = document.getElementById('users');
const toolSel = document.getElementById('tool');
const colorInp = document.getElementById('color');
const sizeInp = document.getElementById('size');
const undoBtn = document.getElementById('undo');
const redoBtn = document.getElementById('redo');
const latencyEl = document.getElementById('latency');
const roomLabel = document.getElementById('roomLabel');

const socket = connect();

let self = { id: null, color: '#000' };
let users = new Map(); // id -> {id,color}
let history = []; // ops
let tombstones = new Set();
let version = 0;

let drawing = false;
let currentOp = null;
let lastSend = 0;

const offscreen = document.createElement('canvas');
const offctx = offscreen.getContext('2d');

function resize() {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.floor(rect.width * dpr);
  const h = Math.floor(rect.height * dpr);
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w; canvas.height = h;
    offscreen.width = w; offscreen.height = h;
    ctx.setTransform(dpr,0,0,dpr,0,0);
    offctx.setTransform(dpr,0,0,dpr,0,0);
    redrawAll();
  }
}
window.addEventListener('resize', resize);

function pathFromPoints(p0, p1, p2) {
  // Quadratic smoothing: draw curve from p0 to midpoint(p1,p2) with control p1
  ctx.beginPath();
  ctx.moveTo(p0.x, p0.y);
  const cx = p1.x, cy = p1.y;
  const mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
  ctx.quadraticCurveTo(cx, cy, mx, my);
}

function drawOp(targetCtx, op, uptoCount = null) {
  const pts = uptoCount ? op.points.slice(0, uptoCount) : op.points;
  if (pts.length < 1) return;
  targetCtx.save();
  targetCtx.lineCap = 'round';
  targetCtx.lineJoin = 'round';
  targetCtx.lineWidth = op.size;
  if (op.mode === 'erase') {
    targetCtx.globalCompositeOperation = 'destination-out';
    targetCtx.strokeStyle = 'rgba(0,0,0,1)';
  } else {
    targetCtx.globalCompositeOperation = 'source-over';
    targetCtx.strokeStyle = op.color;
  }
  if (pts.length === 1) {
    // Dot
    targetCtx.beginPath();
    targetCtx.arc(pts[0].x, pts[0].y, op.size/2, 0, Math.PI*2);
    targetCtx.fillStyle = op.mode === 'erase' ? 'rgba(0,0,0,1)' : op.color;
    targetCtx.fill();
  } else {
    targetCtx.beginPath();
    targetCtx.moveTo(pts[0].x, pts[0].y);
    for (let i=1;i<pts.length;i++) {
      const p1 = pts[i-1];
      const p2 = pts[i];
      // simple smoothing using lineTo; quadratic optional
      targetCtx.lineTo(p2.x, p2.y);
    }
    targetCtx.stroke();
  }
  targetCtx.restore();
}

function redrawAll() {
  offctx.clearRect(0,0,offscreen.width, offscreen.height);
  for (const op of history) {
    if (!tombstones.has(op.opId)) drawOp(offctx, op);
  }
  // copy to visible
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(offscreen, 0, 0);
}

function updateUsersUI() {
  usersList.innerHTML = '';
  for (const u of users.values()) {
    const li = document.createElement('li');
    li.className = 'user';
    const b = document.createElement('span');
    b.className = 'badge';
    b.style.background = u.color;
    const label = document.createElement('span');
    label.textContent = u.id.slice(0, 8);
    li.appendChild(b); li.appendChild(label);
    usersList.appendChild(li);
  }
}

function addCursor(id, color) {
  const el = document.createElement('div');
  el.className = 'cursor';
  el.style.borderColor = color;
  el.style.color = '#111';
  el.dataset.id = id;
  el.textContent = id.slice(0,4);
  cursorsLayer.appendChild(el);
  return el;
}

function updateCursor(id, x, y) {
  let el = cursorsLayer.querySelector(`[data-id="${id}"]`);
  if (!el) {
    const u = users.get(id);
    el = addCursor(id, u ? u.color : '#000');
  }
  el.style.left = x + 'px';
  el.style.top = y + 'px';
}

function removeCursor(id) {
  const el = cursorsLayer.querySelector(`[data-id="${id}"]`);
  if (el) el.remove();
}

// Input handling
function getPos(e) {
  const rect = canvas.getBoundingClientRect();
  if (e.touches && e.touches[0]) {
    return { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
  }
  return { x: e.clientX - rect.left, y: e.clientY - rect.top };
}

function beginStroke(x, y) {
  drawing = true;
  currentOp = {
    opId: crypto.randomUUID(),
    author: self.id,
    color: colorInp.value,
    size: parseInt(sizeInp.value, 10),
    mode: toolSel.value === 'erase' ? 'erase' : 'draw',
    points: [{ x, y, ts: Date.now() }]
  };
  // local predictive draw
  drawOp(ctx, currentOp);
  socket.emit('stroke:begin', { 
    opId: currentOp.opId, 
    color: currentOp.color, 
    size: currentOp.size, 
    mode: currentOp.mode, 
    start: {x,y}, 
    ts: Date.now()
  });
}

function appendPoint(x, y) {
  if (!drawing || !currentOp) return;
  const pt = { x, y, ts: Date.now() };
  currentOp.points.push(pt);
  // draw incrementally on screen
  drawOp(ctx, currentOp, currentOp.points.length);
  // batch send at ~16ms intervals
  const now = performance.now();
  if (now - lastSend > 16) {
    lastSend = now;
    socket.emit('stroke:points', { opId: currentOp.opId, points: currentOp.points.slice(-8) });
  }
}

function endStroke() {
  if (!drawing || !currentOp) return;
  socket.emit('stroke:end', { opId: currentOp.opId });
  drawing = false;
  currentOp = null;
  // sync offscreen by redrawing incremental layer
  redrawAll();
}

canvas.addEventListener('mousedown', (e) => { const p = getPos(e); beginStroke(p.x, p.y); });
canvas.addEventListener('mousemove', (e) => {
  const p = getPos(e);
  socket.emit('cursor:update', p);
  if (drawing) appendPoint(p.x, p.y);
});
window.addEventListener('mouseup', endStroke);

canvas.addEventListener('touchstart', (e) => { const p = getPos(e); beginStroke(p.x, p.y); });
canvas.addEventListener('touchmove', (e) => { const p = getPos(e); socket.emit('cursor:update', p); if (drawing) appendPoint(p.x, p.y); });
window.addEventListener('touchend', endStroke);

undoBtn.addEventListener('click', () => socket.emit('undo'));
redoBtn.addEventListener('click', () => socket.emit('redo'));
window.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); socket.emit('undo'); }
  if (e.ctrlKey && e.key.toLowerCase() === 'z' && e.shiftKey) { e.preventDefault(); socket.emit('redo'); }
});

// Socket bindings
socket.on('connect', () => {
  // ping for latency display
  const pingStart = performance.now();
  socket.timeout(1000).emit('cursor:update', {x:-999,y:-999}, () => {
    const ms = Math.round(performance.now() - pingStart);
    latencyEl.textContent = `latency ~${ms}ms`;
  });
});

socket.on('init', (state) => {
  self = state.self;
  users = new Map(state.users.map(u => [u.id, u]));
  history = state.history || [];
  tombstones = new Set(state.tombstones || []);
  version = state.version || 0;
  colorInp.value = self.color;
  updateUsersUI();
  resize();
  redrawAll();
});

socket.on('user:join', (u) => {
  users.set(u.id, u);
  updateUsersUI();
  addCursor(u.id, u.color);
});

socket.on('user:leave', ({id}) => {
  users.delete(id); updateUsersUI(); removeCursor(id);
});

socket.on('cursor:update', ({id,x,y}) => {
  updateCursor(id, x, y);
});

socket.on('stroke:begin', (op) => {
  // If it's ours, rely on our local drawing, else draw incremental
  if (op.author !== self.id) {
    // ensure history has the op
    const idx = history.findIndex(o => o.opId === op.opId);
    if (idx === -1) history.push({ ...op });
    drawOp(ctx, op, 1);
  } else {
    // ensure server's op is known (authoritative reference)
    const idx = history.findIndex(o => o.opId === op.opId);
    if (idx === -1) history.push({ ...op });
  }
});

socket.on('stroke:points', ({opId, points}) => {
  const op = history.find(o => o.opId === opId);
  if (!op) return;
  op.points.push(...points);
  // Only draw streaming for remote users to avoid double-draw
  if (op.author !== self.id) {
    drawOp(ctx, op, op.points.length);
  }
});

socket.on('stroke:end', ({opId}) => {
  const op = history.find(o => o.opId === opId);
  if (!op) return;
  // finalize by redrawing from offscreen to guarantee determinism
  redrawAll();
});

socket.on('history:patch', ({action, opId, version: v}) => {
  version = v;
  if (action === 'undo') tombstones.add(opId);
  if (action === 'redo') tombstones.delete(opId);
  redrawAll();
});

// Room label
(() => {
  const url = new URL(window.location.href);
  const room = url.searchParams.get('room') || 'default';
  roomLabel.textContent = `Room: ${room}`;
})();

resize();
